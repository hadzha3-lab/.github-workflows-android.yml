package app.lariat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlin.random.Random

data class Game(val name:String, val category:String, val engine:Engine)
enum class Engine { PATHS,SUDOKU,MINES,LIGHTS,MASTERMIND,TTT,CONNECT4,NIM,PAIRS,SEQUENCE,NUMBER,
 COUNT,REACTION,STROOP,ODD,MATH,WORDS,ORDER,MERGE,SLIDE,MAZE,SNAKE,RANDOM }

val games = listOf(
    Game("Соедини пути", "Логика", Engine.PATHS),
    Game("Судоку", "Логика", Engine.SUDOKU),
    Game("Сапёр", "Логика", Engine.MINES),
    Game("Погаси свет", "Логика", Engine.LIGHTS),
    Game("Кодовый замок", "Логика", Engine.MASTERMIND),
    Game("Крестики-нолики", "Стратегия", Engine.TTT),
    Game("Четыре в ряд", "Стратегия", Engine.CONNECT4),
    Game("Nim", "Стратегия", Engine.NIM),
    Game("Пары", "Память", Engine.PAIRS),
    Game("Запомни порядок", "Память", Engine.SEQUENCE),
    Game("Повтори сигнал", "Память", Engine.SEQUENCE),
    Game("Запомни число", "Память", Engine.NUMBER),
    Game("Запомни узор", "Память", Engine.PAIRS),
    Game("Быстрый счёт", "Внимание", Engine.COUNT),
    Game("Реакция", "Внимание", Engine.REACTION),
    Game("Цвет или слово", "Внимание", Engine.STROOP),
    Game("Найди лишнее", "Внимание", Engine.ODD),
    Game("Найди цель", "Внимание", Engine.ODD),
    Game("Математический рывок", "Числа", Engine.MATH),
    Game("Собери 24", "Числа", Engine.MATH),
    Game("Числовой ряд", "Числа", Engine.NUMBER),
    Game("Больше или меньше", "Числа", Engine.NUMBER),
    Game("Простые числа", "Числа", Engine.ODD),
    Game("Магическая сумма", "Числа", Engine.MATH),
    Game("Анаграммы", "Слова", Engine.WORDS),
    Game("Перемешанные слова", "Слова", Engine.WORDS),
    Game("Пропущенная буква", "Слова", Engine.WORDS),
    Game("Цепочка слов", "Слова", Engine.WORDS),
    Game("Угадай слово", "Слова", Engine.WORDS),
    Game("Поиск слов", "Слова", Engine.WORDS),
    Game("Совпадение цветов", "Узоры", Engine.STROOP),
    Game("Совпадение фигур", "Узоры", Engine.ODD),
    Game("Продолжи узор", "Узоры", Engine.NUMBER),
    Game("Совпадение плиток", "Узоры", Engine.PAIRS),
    Game("Порядок оттенков", "Узоры", Engine.ORDER),
    Game("2048", "Головоломки", Engine.MERGE),
    Game("Пятнашки", "Головоломки", Engine.SLIDE),
    Game("Сдвинь блоки", "Головоломки", Engine.SLIDE),
    Game("Сортировка", "Головоломки", Engine.ORDER),
    Game("Трубы", "Головоломки", Engine.PATHS),
    Game("Лабиринт", "Головоломки", Engine.MAZE),
    Game("Нонограмма", "Головоломки", Engine.LIGHTS),
    Game("Змейка", "Аркады", Engine.SNAKE),
    Game("Уклонение", "Аркады", Engine.REACTION),
    Game("Тап-спринт", "Аркады", Engine.REACTION),
    Game("Рефлекс", "Аркады", Engine.REACTION),
    Game("Смена полосы", "Аркады", Engine.REACTION),
    Game("Дзен-баланс", "Спокойствие", Engine.ORDER),
    Game("Ритм дыхания", "Спокойствие", Engine.SEQUENCE),
    Game("Испытание дня", "Сегодня", Engine.RANDOM),
    Game("Двоичный переворот", "Логика", Engine.LIGHTS),
    Game("Ход конём", "Логика", Engine.PATHS),
    Game("Уравнения", "Числа", Engine.MATH),
    Game("Сетка букв", "Слова", Engine.WORDS),
    Game("Память импульса", "Память", Engine.SEQUENCE),
    Game("Сетка внимания", "Внимание", Engine.COUNT),
    Game("Шахматная тактика", "Стратегия", Engine.NIM),
    Game("Сортировка цветов", "Головоломки", Engine.ORDER),
    Game("Построй маршрут", "Головоломки", Engine.PATHS),
    Game("Сетка реакции", "Аркады", Engine.REACTION)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LariatApp() }
    }
}

private val bg = Color(0xFF10162D)
private val glass = Color(0x263B4774)
private val accent = Color(0xFF9BB8FF)
private val peach = Color(0xFFFFC9A8)

@Composable fun LariatApp() {
    var selected by remember { mutableStateOf<Game?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(primary=accent, secondary=peach, background=bg, surface=glass)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17203F), bg)))) {
            if (selected == null) Home { selected = it } else GameScreen(selected!!) { selected = null }
        }
    }
}

@Composable fun Home(open:(Game)->Unit) {
    var filter by remember { mutableStateOf("Все") }
    val cats = listOf("Все") + games.map{it.category}.distinct()
    Column(Modifier.fillMaxSize().padding(top=18.dp)) {
        Column(Modifier.padding(horizontal=20.dp)) {
            Text("Lariat", fontSize=38.sp, fontWeight=FontWeight.Light, color=Color.White)
            Text("Маленькие игры. Ясная голова. Всегда офлайн.", color=Color.White.copy(.65f))
            Spacer(Modifier.height(18.dp))
            GlassCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                    Column { Text("Игра дня", color=Color.White, fontWeight=FontWeight.Bold); Text("5 случайных испытаний", color=Color.White.copy(.6f)) }
                    Text("▶", fontSize=26.sp, color=accent, modifier=Modifier.clickable{open(games.last{it.name=="Испытание дня"})})
                }
            }
        }
        LazyRow(contentPadding=PaddingValues(20.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            items(cats) { c -> FilterChip(selected=filter==c,onClick={filter=c},label={Text(c)}) }
        }
        val shown = if(filter=="Все") games else games.filter{it.category==filter}
        BoxWithConstraints(Modifier.fillMaxSize()) {
        val columns = when { maxWidth < 360.dp -> 1; maxWidth < 700.dp -> 2; else -> 3 }
        LazyVerticalGrid(columns=GridCells.Fixed(columns), contentPadding=PaddingValues(20.dp),
            horizontalArrangement=Arrangement.spacedBy(12.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            items(shown) { g -> GlassCard(Modifier.clickable{open(g)}) {
                Text(g.name, color=Color.White, fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp)); Text(g.category, color=accent, fontSize=12.sp)
                Spacer(Modifier.height(14.dp)); Text("Играть  →", color=Color.White.copy(.65f))
            } }
        }
        }
    }
}

@Composable fun GlassCard(mod:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(mod.clip(RoundedCornerShape(24.dp)).background(glass).border(1.dp, Color.White.copy(.12f), RoundedCornerShape(24.dp)).padding(18.dp), content=content)
}

@Composable fun GameScreen(game:Game, back:()->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("‹", fontSize=40.sp, color=Color.White, modifier=Modifier.clickable{back()}.padding(end=16.dp))
            Column { Text(game.name, color=Color.White, fontSize=26.sp, fontWeight=FontWeight.Bold); Text(game.category, color=accent) }
        }
        Spacer(Modifier.height(22.dp))
        GlassCard(Modifier.fillMaxWidth().weight(1f)) {
            when(game.engine) {
                Engine.LIGHTS,Engine.MINES,Engine.PAIRS,Engine.ODD,Engine.COUNT -> GridTapGame(game.engine)
                Engine.TTT,Engine.CONNECT4 -> TicGame()
                Engine.MATH -> MathGame()
                Engine.WORDS -> WordGame()
                Engine.SEQUENCE,Engine.NUMBER,Engine.STROOP,Engine.REACTION -> ReflexGame(game.engine)
                Engine.MERGE,Engine.SLIDE,Engine.ORDER -> NumberTiles()
                Engine.RANDOM -> RandomDaily()
                else -> PathLikeGame()
            }
        }
    }
}

@Composable fun GridTapGame(engine:Engine) {
    var score by remember { mutableIntStateOf(0) }
    var target by remember { mutableIntStateOf(Random.nextInt(16)) }
    Text("Score $score", color=Color.White, fontSize=22.sp)
    Spacer(Modifier.height(18.dp))
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        repeat(4) { r -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            repeat(4) { c -> val i=r*4+c
                Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                    .background(if(i==target) peach.copy(.75f) else Color.White.copy(.07f))
                    .clickable { if(i==target) {score++; target=Random.nextInt(16)} else score=maxOf(0,score-1) })
            }
        } }
    }
    Spacer(Modifier.height(14.dp)); Text("Tap the highlighted / odd tile. Variants change rules per game.", color=Color.White.copy(.6f))
}

@Composable fun TicGame() {
    var board by remember { mutableStateOf(List(9){""}) }
    var xTurn by remember { mutableStateOf(true) }
    Text("Игра вдвоём на одном телефоне", color=Color.White)
    Spacer(Modifier.height(18.dp))
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        repeat(3){r->Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            repeat(3){c->val i=r*3+c
                Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(.07f))
                    .clickable{if(board[i].isEmpty()){board=board.toMutableList().also{it[i]=if(xTurn)"X" else "O"};xTurn=!xTurn}},
                    contentAlignment=Alignment.Center){Text(board[i],fontSize=34.sp,color=if(board[i]=="X")accent else peach)}
            }
        }}
    }
    Spacer(Modifier.height(18.dp)); Button(onClick={board=List(9){""}}){Text("Заново")}
}

@Composable fun MathGame() {
    var a by remember{mutableIntStateOf(Random.nextInt(2,20))}; var b by remember{mutableIntStateOf(Random.nextInt(2,20))}
    var score by remember{mutableIntStateOf(0)}; var answer by remember{mutableStateOf("")}
    Text("Решай быстро", color=Color.White.copy(.7f)); Text("$a + $b = ?", fontSize=40.sp,color=Color.White)
    OutlinedTextField(answer,{answer=it.filter(Char::isDigit)},label={Text("Ответ")})
    Spacer(Modifier.height(12.dp)); Button(onClick={if(answer.toIntOrNull()==a+b)score++;a=Random.nextInt(2,20);b=Random.nextInt(2,20);answer=""}){Text("Проверить")}
    Spacer(Modifier.height(16.dp)); Text("Score $score",color=accent)
}

@Composable fun WordGame() {
    val words=listOf("ЛАРИАТ","ЗАГАДКА","ПАМЯТЬ","ФОКУС","ЛОГИКА","ОФЛАЙН")
    var word by remember{mutableStateOf(words.random())}
    var input by remember{mutableStateOf("")}
    val scrambled=remember(word){word.toList().shuffled().joinToString("")}
    Text("Собери слово",color=Color.White.copy(.65f));Text(scrambled,fontSize=34.sp,color=peach)
    OutlinedTextField(input,{input=it.uppercase()},label={Text("Слово")})
    Spacer(Modifier.height(12.dp));Button(onClick={if(input==word){word=words.random();input=""}}){Text("Готово")}
}

@Composable fun ReflexGame(engine:Engine) {
    var value by remember{mutableIntStateOf(Random.nextInt(1,10))};var score by remember{mutableIntStateOf(0)}
    Text(if(engine==Engine.REACTION)"Нажми, когда будешь готов" else "Запоминай и реагируй",color=Color.White.copy(.65f))
    Spacer(Modifier.height(30.dp))
    Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(28.dp)).background(accent.copy(.22f)).clickable{score++;value=Random.nextInt(1,10)},contentAlignment=Alignment.Center){
        Text(value.toString(),fontSize=72.sp,color=Color.White)
    }
    Spacer(Modifier.height(20.dp));Text("Score $score",color=peach)
}

@Composable fun NumberTiles() {
    var nums by remember{mutableStateOf((1..16).shuffled())}
    Text("Расставляй и объединяй плитки",color=Color.White.copy(.65f));Spacer(Modifier.height(16.dp))
    Column(verticalArrangement=Arrangement.spacedBy(7.dp)){repeat(4){r->Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
        repeat(4){c->val i=r*4+c;Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(.08f)).clickable{nums=nums.shuffled()},contentAlignment=Alignment.Center){Text(nums[i].toString(),color=Color.White,fontSize=20.sp)}}
    }}}
    Spacer(Modifier.height(16.dp));Button(onClick={nums=(1..16).shuffled()}){Text("Перемешать")}
}

@Composable fun PathLikeGame() {
    var moves by remember{mutableIntStateOf(0)}
    Text("Логическое поле",color=Color.White.copy(.65f));Spacer(Modifier.height(18.dp))
    Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)).background(Color.White.copy(.06f)).clickable{moves++},contentAlignment=Alignment.Center){
        Text("Connect • route • solve\n\nMoves: $moves",color=Color.White,fontSize=24.sp)
    }
    Spacer(Modifier.height(14.dp));Text("This engine is shared by path, maze, pipes and route puzzles.",color=Color.White.copy(.55f))
}

@Composable fun RandomDaily() {
    val picks=remember{games.filter{it.category!="Сегодня"}.shuffled().take(5)}
    Text("Пять игр на сегодня",fontSize=24.sp,color=Color.White,fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(14.dp));picks.forEachIndexed{i,g->Text("${i+1}. ${g.name}",color=Color.White,modifier=Modifier.padding(vertical=8.dp))}
}
